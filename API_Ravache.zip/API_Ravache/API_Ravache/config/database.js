module.exports = {
    dialect: 'postgres',
    host: 'localhost',
    username: 'postgres',
    password: 'banco123',
    database: 'apinode',
    port: "5432",
    define: {
        timestamp: true,
        underscored: true
    }
}